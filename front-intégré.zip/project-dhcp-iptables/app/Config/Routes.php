<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/Hote','Home::hote');
$routes->get('/Dhcp','Home::dhcp');
$routes->get('/Subnet','Home::subnet');
$routes->get('/Iptables','Home::iptables');
