<?php

namespace Config;

use CodeIgniter\Config\AutoloadConfig;

class Autoload extends AutoloadConfig
{
    public $psr4 = [
        APP_NAMESPACE => APPPATH,
    ];

    public $classmap = [];

    public $files = [
        FCPATH . 'app/assets/Dhcp.svg',
        FCPATH . 'app/assets/bootstrap.min.css',
        FCPATH . 'app/assets/bootstrap.min.js',
        FCPATH . 'app/assets/dhcp.png',
        FCPATH . 'app/assets/firewall.jpg',
        FCPATH . 'app/assets/firewall.png',
    ];

    public $helpers = [];
}
