<?php

namespace App\Controllers;
use  App\Models\Net;
class Home extends BaseController
{
    public function index(): string
    {

        // $n=new Net();
        // $data['subnet']=$n->getSubnet();
// 
        // return view('subnet',$data);
        return view('index');
     }
     public function subnet(): string 
     {
        $n=new Net();
        $data['subnet']=$n->getSubnet();
        return view('subnet',$data);
     }
    public function hote():string
    {
        $n=new Net();
        $data['hosts']=$n->getHosts();
        return view('hosts',$data);
    }

    public function dhcp():string 
    {
        return view('dhcp');
    }
    public function iptables():string 
    {
        return view('iptables');
    }
}
