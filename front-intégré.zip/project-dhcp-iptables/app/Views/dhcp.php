<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire IP</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('app/assets/bootstrap.bundle.min.css');?>">
</head>
<body>
    <div class="container">
        <h2 style="text-align: center;" class="m-4">Configuration actuelle</h2>
        <form id="ipForm">
            <div class="form-group m-2">
                <label for="networkAddress" class="m-2">Adresse IP du réseau</label>
                <input type="text" class="form-control" id="networkAddress" placeholder="">
            </div>
            <div class="form-group m-2">
                <label for="startRange" class="m-2">Début de la plage</label>
                <input type="text" class="form-control" id="startRange" placeholder="">
            </div>
            <div class="form-group m-2">
                <label for="endRange" class="m-2">Fin de la plage</label>
                <input type="text" class="form-control" id="endRange" placeholder="">
            </div>
            <button type="submit" class="btn btn-dark mt-3" style="width: 40%;">Valider</button>
        </form>
    </div>
      
    <script src="<?php echo base_url('app/assets/bootstrap.bundle.min.js');?>"></script>
    <script>
        document.getElementById('ipForm').addEventListener('submit', function(event) {
        event.preventDefault(); 

        const networkAddress = document.getElementById('networkAddress').value;
        const startRange = document.getElementById('startRange').value;
        const endRange = document.getElementById('endRange').value;

        const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        if (!ipRegex.test(networkAddress) || !ipRegex.test(startRange) || !ipRegex.test(endRange)) {
            alert('Veuillez entrer des adresses IP valides.');
            return;
        }

        const networkAddressParts = networkAddress.split('.');
        const startRangeParts = startRange.split('.');
        const endRangeParts = endRange.split('.');

        if(networkAddressParts[networkAddressParts.length - 1] == "0"){
            alert('Veuillez entrer une adresse réseau valide.');
            return;
        } 
        
    });
        


    </script>
</body>
</html>