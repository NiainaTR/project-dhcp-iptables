<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <style>
        * {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  font-family: Arial, Helvetica, sans-serif;
}

body {
  background: #ffffff;
}

header {
  z-index: 999;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 200px;
  transition: 0.5s ease;
  background-color: #324151;
  box-shadow: 0 0 5px 5px;
}

header .title {
  color: rgb(255, 255, 255);
  font-size: 2em;
  font-weight: 700;
  text-transform: uppercase;
  text-decoration: none;
}

header .navigator {
  position: relative;
}

header .navigator .navigator-items a {
  position: relative;
  font-size: 1.5em;
  font-weight: 500;
  text-decoration: none;
  padding: 10px;
  margin: 0px 10px;
  color: white;
  transition: 0.3s ease;
}

header .navigator .navigator-items a:before {
  background-color: white;
  content: "";
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0;
  height: 3px;
  transition: 0.3s ease;
}

header .navigator .navigator-items a:hover:before {
  width: 100%;
}

.content {
  margin: 100px 100px;
}

.content-item {
  position: relative;
  left: 10vw;
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;

}

.content-item h1 {
  color: rgb(0, 0, 0);
  font-size: 3em;
  text-transform: uppercase;
  text-align: center;
}

.context {
  margin: 10vh 30vw;
  font-size: 1.3em;
  position: relative;
  right: 30vw;
}

.content a {
  padding: 15px;
  font-size: 1.5em;
  background-color: #324151;
  text-decoration: none;
  text-align: center;
  border-radius: 10px;
  color: white;
}

.image {
  background-image: url("d4e532f4ce59fd2d74625ce7fb56136c.jpg");
  background-repeat: no-repeat;
  background-size: contain;
  background-position: center;
  width: 450px;
  height: 100px;
  display: flex;
  justify-content: flex-end;
  position: relative;
  bottom: 40vw;
  left: 50vw;
  transition: transform 0.3s, box-shadow 0.3s;
}
.image:hover {
  transform: scale(1.1); 
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.75); 
} 


    </style>
    <title>Tables des règles</title>
  </head>
  <body>
    <header>
      <a href="" class="title">FIRE WALL</a>
      <div class="navigator">
        <div class="navigator-items">
          <a href="./index.html">Home</a>
          <a href="./list.php">List</a>
          <a href="./formulaire_add.php">Add</a>
          <a href="./policy.php">Policy</a>
        </div>
      </div>
    </header>

    <div class="content">
      <div class="content-item">
        <h1>Welcome</h1>
        <div class="context">
          <p>This sites can access on the tables rules IP!!!</p>
          <br />
          <a href="">Voir plus...</a>
        </div>
      </div>
      <div class="image"> </div>
    </div>
    
  </body>
</html>
